use project;
select * from actions2load; 
/* the total records on the action2load table is 17070*/

    # Checking unique account_id   
SELECT DISTINCT(account_id)FROM actions2load;
    
#total number of unique account id is 2051
SELECT count(DISTINCT(account_id))FROM actions2load;
    
    
#total number of unique events is 20
SELECT count(DISTINCT
   (event_type))
FROM
    actions2load;
    
    
    /* number of times events occurred based on different times of the day*/
SELECT 
    DATE_FORMAT(event_time, '%H:%i') AS time_of_the_day,
    COUNT(*) AS event_count
FROM
    actions2load
GROUP BY time_of_the_day
ORDER BY time_of_the_day ;

#Checking events that are most common - by counting which events has the highest occurence


/* ReadingOwnedBook event_type has the highest number of occurrence of 7108 
followed by ReadingOpenChapter event_type with 1637occurence*/
SELECT 
    event_type, COUNT('event_type') AS event_frequency
FROM
    actions2load
GROUP BY event_type
ORDER BY event_frequency DESC;

#Checking events that are least common - by counting which events has the lowest occurence
/* ProductSeeFreeLinkOpened event_type has the lowest number of occurrence of 1 
followed by ProductSeeFreeLinkOpenedevent_type with 21 occurence*/
SELECT 
    event_type, COUNT('event_type') AS event_frequency
FROM
    actions2load
GROUP BY event_type
ORDER BY event_frequency ASC;

#Checking account_id with the highest number of events -
/* Account Id with the highest number of event is 954c5420b7247345858b62c84d606bb7 (451 events occurence) */
SELECT 
    account_id, COUNT('account_id') AS event_frequency
FROM
    actions2load
GROUP BY account_id
ORDER BY event_frequency Desc LIMIT 1;

#Checking events that are most common - by counting which events has the highest occurence
/* ReadingOwnedBook event_type has the highest number of occurrence of 7108
 followed by ReadingOpenChapter event_type with 1637 occurence*/
SELECT 
    event_type, COUNT('event_type') AS event_frequency
FROM
    actions2load
GROUP BY event_type
ORDER BY event_frequency DESC;


#Checking events that are least common - by counting which events has the lowest occurence
/* ProductSeeFreeLinkOpened event_type has the lowest number of occurrence of 1 
followed by ProductLiveaudioUpsell event_type with 21 occurence*/
SELECT 
    event_type, COUNT('event_type') AS event_frequency
FROM
    actions2load
GROUP BY event_type
ORDER BY event_frequency ASC;


#Checking account_id with the highest number of events -
/* Account Id with the highest number of event is 954c5420b7247345858b62c84d606bb7 
(451 events occurence) */
SELECT 
    account_id, COUNT('account_id') AS event_frequency
FROM
    actions2load
GROUP BY account_id
ORDER BY event_frequency Desc LIMIT 1;
    